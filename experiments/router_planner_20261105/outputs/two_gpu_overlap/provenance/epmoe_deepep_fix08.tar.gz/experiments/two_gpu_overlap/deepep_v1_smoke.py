"""Real DeepEP v1 dispatch/combine + separately labelled NCCL weight prefetch.

Synthetic correctness probe; no real model or performance claim. The repeated
no-CPU-sync dispatch also exercises capacity buffers and invalid tail rows.
"""
import argparse
import json
import os
from pathlib import Path

import torch
import torch.distributed as dist

from deepep_adapter import validate_plan
from deepep_v1_adapter import DeepEPV1PlannedAdapter, NCCLReplicaPrefetch, UPSTREAM_COMMIT, build_provenance


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--tokens", type=int, default=512)
    p.add_argument("--hidden", type=int, default=128)
    p.add_argument("--weight-elements", type=int, default=4096)
    p.add_argument("--output", type=Path, default=Path("deepep_v1_smoke.json"))
    a = p.parse_args()
    torch.cuda.set_device(int(os.environ["LOCAL_RANK"]))
    dist.init_process_group("nccl")
    rank = dist.get_rank()
    weight_group = dist.new_group([0, 1], backend="nccl")
    result = {"status": "running", "token_backend": "DeepEP v1.2.1 intranode",
              "expert_backend": "torch.distributed NCCL batch P2P",
              "reference_commit": UPSTREAM_COMMIT,
              "workload": "synthetic correctness probe", "failures": [], "checks": []}
    adapter = None
    try:
        result['build_provenance'] = build_provenance()
        E, K, B, local = 352, 8, 8, 176
        adapter = DeepEPV1PlannedAdapter(dist.group.WORLD, per_source=a.tokens,
            hidden=a.hidden, topk=K, num_experts=E, extra_slots=B)
        cpu_map = torch.full((2, B), -1, dtype=torch.int32)
        cpu_map[0, 0], cpu_map[1, 0] = local, 0
        mapping = cpu_map.cuda()
        ids = torch.arange(local, device="cuda") + rank * local
        factors = ((ids % 7) + 1).to(torch.bfloat16)
        original = factors[:, None].expand(-1, a.weight_elements).contiguous()
        replicas = torch.full((B, a.weight_elements), -1, device="cuda", dtype=torch.bfloat16)
        prefetch = NCCLReplicaPrefetch(weight_group, original, replicas, cpu_map)
        logical = (torch.arange(a.tokens*K, device="cuda").reshape(-1, K) % E).int()
        owner = logical // local
        owner = torch.where(logical == 0, 1, torch.where(logical == local, 0, owner)).int()
        validate_plan(logical, owner, mapping, E)
        x = torch.ones((a.tokens, a.hidden), dtype=torch.bfloat16, device="cuda")
        router = torch.full((a.tokens, K), 1/K, dtype=torch.float32, device="cuda")
        for no_cpu_sync in (False, True):
            torch.cuda.synchronize()
            dist.barrier()
            weights = prefetch.start()
            token = adapter.start_token_dispatch(x, logical, owner, mapping, router,
                                                 no_cpu_sync=no_cpu_sync)
            recv_x, recv_idx, recv_router, counts, handle = token.wait()
            weights.wait()
            # v1 receive rows are deduplicated by token/destination rank. Sum all
            # valid local expert contributions for each row before combine.
            local_factors = torch.cat((original[:, 0], replicas[:, 0]))
            valid = recv_idx >= 0
            selected = local_factors[recv_idx.clamp_min(0)]
            contribution = torch.where(valid, selected.float() * recv_router, 0).sum(dim=1)
            out = (recv_x.float() * contribution[:, None]).bfloat16()
            # Avoid NaN propagation if capacity rows contain unspecified payload.
            out.masked_fill_(~valid.any(dim=1)[:, None], 0)
            combined, _, event = adapter.combine(out, handle)
            event.current_stream_wait()
            expected = (((logical % 7) + 1).float()/K).sum(dim=1)
            torch.cuda.synchronize()
            error = (combined.float() - expected[:, None]).abs().max().item()
            assert error == 0, error
            assert bool((replicas[0] == (int(cpu_map[rank, 0]) % 7 + 1)).all())
            assert bool((replicas[1:] == -1).all())
            result["checks"].append(dict(no_cpu_sync=no_cpu_sync, max_abs_error=error,
                replica_value_verified=True, unused_slots_unchanged=True))
        result.update(status="passed", weight_bytes_sent=prefetch.bytes_sent,
                      weight_bytes_received=prefetch.bytes_received)
    except Exception as exc:
        result["status"] = "failed"
        result["failures"].append(f"{type(exc).__name__}: {exc}")
        raise
    finally:
        a.output.parent.mkdir(parents=True, exist_ok=True)
        a.output.with_name(a.output.stem+f"_rank{rank}.json").write_text(
            json.dumps(result, indent=2)+"\n")
        if adapter is not None:
            adapter.destroy()
        dist.destroy_process_group()


if __name__ == "__main__":
    main()
