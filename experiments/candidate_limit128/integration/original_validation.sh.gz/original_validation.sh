#!/bin/bash
set -u
cd /inspire/hdd/project/embodied-multimodality/liangzuning-253108090053/moonep_cap128_delivery_20261106
export PYTHONPATH=. MOONEP_MEM_HANDLE_TYPE=fd TORCH_CUDA_ARCH_LIST=9.0 MAX_JOBS=4 OMP_NUM_THREADS=1
export TORCH_EXTENSIONS_DIR="$PWD/build/extensions"
mkdir -p evidence_delivery
run_check() {
  name="$1"
  shift
  "$@" > "evidence_delivery/${name}.log" 2>&1
  result=$?
  echo "$result" > "evidence_delivery/${name}.exit"
  if [ "$result" != 0 ]; then exit "$result"; fi
}
run_check host_config_01 python -m pytest -q tests/test_planner_config.py
run_check selector_01 python -m pytest -q -s tests/test_sampled_candidate_limit.py -k selector
run_check cap128_public_01 python -m torch.distributed.run --standalone --nproc_per_node=8 -m pytest -q -s tests/test_sampled_candidate_limit.py -k 'not selector'
run_check compatibility_public_01 python -m torch.distributed.run --standalone --nproc_per_node=8 -m pytest -q -s tests/test_sampled_group.py
for cap in 0 128; do
  run_check "benchmark_cap${cap}_01" python -m torch.distributed.run --standalone --nproc_per_node=8 -m tests.benchmark_sampled_candidate_limit --fixture-root fixtures --candidate-limit "$cap" --rounds 4 --expected-hashes experiments/candidate_limit128/cpu_array_hashes.json --output "evidence_delivery/benchmark_cap${cap}_01.json"
done
date -u > evidence_delivery/complete_01
